This image has been configured to pass the Level 1 profile of the CIS Red Hat Enterprise Linux 6 Benchmark v2.0.1 as assessed by CIS-CAT v3.0.29.  A report has been saved to /home/ec2-user/CIS-CAT_Report.html

Exceptions:

1.5.2 Ensure XD/NX support is enabled
	This is not required or scored for this version of the OS.
4.2.1.4 Ensure rsyslog is configured to send logs to a remote log host
	Configuration of the remote host setting requires knowledge of end user environment.
4.2.4 Ensure permissions on all logfiles are configured
	Upon rebbot the permissions on specific log files are reset to defalt as required by the system.
6.1.10 Ensure no world writable files exist
	Upon rebbot the permissions on specific files are reset to defalt as required by the system.
